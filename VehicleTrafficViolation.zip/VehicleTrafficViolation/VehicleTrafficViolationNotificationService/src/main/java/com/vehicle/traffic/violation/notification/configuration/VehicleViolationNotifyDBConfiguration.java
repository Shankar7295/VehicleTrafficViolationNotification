/**
 * 
 */
package com.vehicle.traffic.violation.notification.configuration;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.vehicle.traffic.violation.notification.entity.Vehicle;

/**
 * This class is used to do the configuration relate to database
 * 
 * @author SHANKAR
 *
 */
@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(basePackages = "com.vehicle.traffic.violation.notification.repository", entityManagerFactoryRef = "vehicleVoilationNotifyEntyMangrFactory", transactionManagerRef = "vehicleVoilationNotifyTransactionManager")
public class VehicleViolationNotifyDBConfiguration {

	/**
	 * This method is used to create teh data source
	 * vehicleVoilationNotifyDatasource
	 * 
	 * @return
	 */
	@Bean(name = "vehicleVoilationNotifyDatasource")
	@ConfigurationProperties(prefix = "spring.datasource")
	public DataSource vehicleVoilationNotifyDatasource() {
		return DataSourceBuilder.create().build();
	}

	/**
	 * This method is used to create the transaction manager
	 * 
	 * @param vehicleVoilationNotifyTransactionManager
	 * @return
	 */
	@Bean(name = "vehicleVoilationNotifyTransactionManager")
	public PlatformTransactionManager vehicleVoilationNotifyTransactionManager(
			LocalContainerEntityManagerFactoryBean vehicleVoilationNotifyTransactionManager) {
		return new JpaTransactionManager(vehicleVoilationNotifyTransactionManager.getObject());
	}

	/**
	 * This method is used to create the entity manager
	 * 
	 * @param vehicleVoilationNotifyDatasource
	 * @param builder
	 * @return
	 */
	@Bean(name = "vehicleVoilationNotifyEntyMangrFactory")
	public LocalContainerEntityManagerFactoryBean vehicleVoilationNotifyEntyMangrFactory(
			@Qualifier("vehicleVoilationNotifyDatasource") DataSource vehicleVoilationNotifyDatasource,
			EntityManagerFactoryBuilder builder) {
		return builder.dataSource(vehicleVoilationNotifyDatasource).packages(Vehicle.class).build();
	}
}
