/**
 * 
 */
package com.vehicle.traffic.violation.notification.exception;

/**
 * This class is used to handle the exception of the application
 * 
 * @author SHANKAR
 *
 */
public class VehicleViolationNotificationException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public VehicleViolationNotificationException() {
		super();

	}

	public VehicleViolationNotificationException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);

	}

	public VehicleViolationNotificationException(String message, Throwable cause) {
		super(message, cause);

	}

	public VehicleViolationNotificationException(String message) {
		super(message);

	}

	public VehicleViolationNotificationException(Throwable cause) {
		super(cause);

	}

}
