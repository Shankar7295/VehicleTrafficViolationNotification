/**
 * 
 */
package com.vehicle.traffic.violation.notification.dto;

import java.util.ArrayList;
import java.util.List;

/**
 * This clasds is used to send notification data to/from the application
 * 
 * @author SHANKAR
 *
 */
public class VehicleViolationNotificationDTO {

	private List<String> vehicleList = new ArrayList<String>();
	private SignalPoliceDTO signalPolice = new SignalPoliceDTO();

	public VehicleViolationNotificationDTO() {
		super();
	}

	public VehicleViolationNotificationDTO(List<String> vehicleList, SignalPoliceDTO signalPolice) {
		super();
		this.vehicleList = vehicleList;
		this.signalPolice = signalPolice;
	}

	public List<String> getVehicleList() {
		return vehicleList;
	}

	public void setVehicleList(List<String> vehicleList) {
		this.vehicleList = vehicleList;
	}

	public SignalPoliceDTO getSignalPolice() {
		return signalPolice;
	}

	public void setSignalPolice(SignalPoliceDTO signalPolice) {
		this.signalPolice = signalPolice;
	}

	@Override
	public String toString() {
		return "VehicleViolationNotification [vehicleList=" + vehicleList + ", signalPolice=" + signalPolice + "]";
	}

}
