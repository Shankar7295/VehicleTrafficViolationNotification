/**
 * 
 */
package com.vehicle.traffic.violation.notification.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;

/**
 * This class holds the Vehicle data
 * 
 * @author SHANKAR
 *
 */
@Entity
public class Vehicle implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@Column(name = "vehicle_number", unique = true)
	private String vehicleNumber;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "customer_id")
	@Cascade(CascadeType.ALL)
	private Customer customer = new Customer();
	@Column(name = "color")
	private String color;
	@Column(name = "model")
	private int model;
	@Column(name = "purchase_date")
	private Date purchaseDate;
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "vehicle")
	@Cascade(CascadeType.ALL)
	private List<VehicleViolationNotification> notifications = new ArrayList<>();

	public Vehicle() {
		super();
	}

	public Vehicle(String vehicleNumber, Customer customer, String color, int model, Date purchaseDate,
			List<VehicleViolationNotification> notifications) {
		super();
		this.vehicleNumber = vehicleNumber;
		this.customer = customer;
		this.color = color;
		this.model = model;
		this.purchaseDate = purchaseDate;
		this.notifications = notifications;
	}

	public String getVehicleNumber() {
		return vehicleNumber;
	}

	public void setVehicleNumber(String vehicleNumber) {
		this.vehicleNumber = vehicleNumber;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public int getModel() {
		return model;
	}

	public void setModel(int model) {
		this.model = model;
	}

	public Date getPurchaseDate() {
		return purchaseDate;
	}

	public void setPurchaseDate(Date purchaseDate) {
		this.purchaseDate = purchaseDate;
	}

	public List<VehicleViolationNotification> getNotifications() {
		return notifications;
	}

	public void setNotifications(List<VehicleViolationNotification> notifications) {
		this.notifications = notifications;
	}

	@Override
	public String toString() {
		return "Vehicle [vehicleNumber=" + vehicleNumber + ", customer=" + customer + ", color=" + color + ", model="
				+ model + ", purchaseDate=" + purchaseDate + ", notifications=" + notifications + "]";
	}

}
