package com.vehicle.traffic.violation.notification.dto;

import java.io.Serializable;
import java.util.Date;

/**
 * This class is used to send vehicle violation data to/from the application
 * 
 * @author SHANKAR
 *
 */

public class VehicleViolationDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String vehicleNumber;
	private String violationDesc;
	private Date violationDate;
	private Double fineAmount;
	private boolean violationCleared = false;

	public VehicleViolationDTO() {
		super();
	}

	public VehicleViolationDTO(String vehicleNumber, String violationDesc, Date violationDate, Double fineAmount,
			boolean violationCleared) {
		super();
		this.vehicleNumber = vehicleNumber;
		this.violationDesc = violationDesc;
		this.violationDate = violationDate;
		this.fineAmount = fineAmount;
		this.violationCleared = violationCleared;
	}

	public String getVehicleNumber() {
		return vehicleNumber;
	}

	public void setVehicleNumber(String vehicleNumber) {
		this.vehicleNumber = vehicleNumber;
	}

	public String getViolationDesc() {
		return violationDesc;
	}

	public void setViolationDesc(String violationDesc) {
		this.violationDesc = violationDesc;
	}

	public Date getViolationDate() {
		return violationDate;
	}

	public void setViolationDate(Date violationDate) {
		this.violationDate = violationDate;
	}

	public Double getFineAmount() {
		return fineAmount;
	}

	public void setFineAmount(Double fineAmount) {
		this.fineAmount = fineAmount;
	}

	public boolean isViolationCleared() {
		return violationCleared;
	}

	public void setViolationCleared(boolean violationCleared) {
		this.violationCleared = violationCleared;
	}

	@Override
	public String toString() {
		return "VehicleViolationDTO [vehicleNumber=" + vehicleNumber + ", violationDesc=" + violationDesc
				+ ", violationDate=" + violationDate + ", fineAmount=" + fineAmount + ", violationCleared="
				+ violationCleared + "]";
	}

}
