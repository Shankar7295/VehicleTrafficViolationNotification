/**
 * 
 */
package com.vehicle.traffic.violation.notification.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vehicle.traffic.violation.notification.entity.Customer;

/**
 * This repository is used for handle customer data
 * 
 * @author SHANKAR
 *
 */
public interface CustomerRepository extends JpaRepository<Customer, Integer> {

}
