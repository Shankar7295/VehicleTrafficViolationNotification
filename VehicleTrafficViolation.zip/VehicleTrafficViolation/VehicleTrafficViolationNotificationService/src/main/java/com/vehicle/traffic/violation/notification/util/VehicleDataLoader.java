/**
 * 
 */
package com.vehicle.traffic.violation.notification.util;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.vehicle.traffic.violation.notification.entity.Vehicle;
import com.vehicle.traffic.violation.notification.repository.VehicleRepository;

/**
 * This class is used to load the pre-data
 * 
 * @author SHANKAR
 *
 */
@Component
public class VehicleDataLoader implements CommandLineRunner {

	@Autowired
	VehicleRepository vehicleRepository;

	@Override
	public void run(String... args) throws Exception {
		vehicleRepository.deleteAll();
		for (int i = 1; i <= 25; i++) {
			Vehicle vehicle = new Vehicle();
			vehicle.setVehicleNumber("IN" + i);
			vehicle.setColor("Blue");
			vehicle.setModel(2020);
			vehicle.setPurchaseDate(new Date());
			vehicle.getCustomer().setAddress("Bangalore");
			vehicle.getCustomer().setMobileNo(123456789);
			vehicle.getCustomer().setName("Shankar" + i);
			vehicleRepository.save(vehicle);
		}

		for (int i = 26; i <= 35; i++) {
			Vehicle vehicle = new Vehicle();
			vehicle.setVehicleNumber("IN" + i);
			vehicle.setColor("White");
			vehicle.setModel(2021);
			vehicle.setPurchaseDate(new Date());
			vehicle.getCustomer().setAddress("Bangalore-South");
			vehicle.getCustomer().setMobileNo(987654321);
			vehicle.getCustomer().setName("Shankar" + i);
			vehicleRepository.save(vehicle);
		}

		for (int i = 36; i <= 50; i++) {
			Vehicle vehicle = new Vehicle();
			vehicle.setVehicleNumber("IN" + i);
			vehicle.setColor("Silver");
			vehicle.setModel(2019);
			vehicle.setPurchaseDate(new Date());
			vehicle.getCustomer().setAddress("Bangalore-North");
			vehicle.getCustomer().setMobileNo(987654321);
			vehicle.getCustomer().setName("Shankar" + i);
			vehicleRepository.save(vehicle);
		}
	}

}
