/**
 * 
 */
package com.vehicle.traffic.violation.notification.dto;

/**
 * This class is used to send signal data to/from application
 * 
 * @author SHANKAR
 *
 */
public class SignalPoliceDTO {

	private String name;
	private String signalAddrs;
	private String emailId;

	public SignalPoliceDTO() {
		super();
	}

	public SignalPoliceDTO(String name, String signalAddrs, String emailId) {
		super();
		this.name = name;
		this.signalAddrs = signalAddrs;
		this.emailId = emailId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSignalAddrs() {
		return signalAddrs;
	}

	public void setSignalAddrs(String signalAddrs) {
		this.signalAddrs = signalAddrs;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	@Override
	public String toString() {
		return "SignalPoliceDTO [name=" + name + ", signalAddrs=" + signalAddrs + ", emailId=" + emailId + "]";
	}

}
