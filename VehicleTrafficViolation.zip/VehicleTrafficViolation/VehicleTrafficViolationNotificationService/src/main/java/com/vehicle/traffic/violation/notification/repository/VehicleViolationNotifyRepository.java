/**
 * 
 */
package com.vehicle.traffic.violation.notification.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vehicle.traffic.violation.notification.entity.VehicleViolationNotification;

/**
 * This class is used to handle vehicle violation notification data
 * 
 * @author SHANKAR
 *
 */
public interface VehicleViolationNotifyRepository extends JpaRepository<VehicleViolationNotification, Integer> {

}
