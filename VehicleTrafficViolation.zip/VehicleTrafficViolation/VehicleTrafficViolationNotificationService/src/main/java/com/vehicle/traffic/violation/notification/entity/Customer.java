/**
 * 
 */
package com.vehicle.traffic.violation.notification.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

/**
 * This class holds the customer entity data
 * 
 * @author SHANKAR
 *
 */
@Entity
public class Customer implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "customer_id")
	private int customerId;
	@Column(name = "customer_name", nullable = false)
	private String name;
	@Column(name = "customer_addrs", nullable = false)
	private String address;
	@Column(name = "customer_mobile_no", nullable = false)
	private int mobileNo;
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "customer")
	private List<Vehicle> vehicles = new ArrayList<>();

	public Customer() {
		super();
	}

	public Customer(int customerId, String name, String address, int mobileNo, List<Vehicle> vehicles) {
		super();
		this.customerId = customerId;
		this.name = name;
		this.address = address;
		this.mobileNo = mobileNo;
		this.vehicles = vehicles;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(int mobileNo) {
		this.mobileNo = mobileNo;
	}

	public List<Vehicle> getVehicles() {
		return vehicles;
	}

	public void setVehicles(List<Vehicle> vehicles) {
		this.vehicles = vehicles;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", name=" + name + ", address=" + address + ", mobileNo="
				+ mobileNo + ", vehicles=" + vehicles + "]";
	}

}
