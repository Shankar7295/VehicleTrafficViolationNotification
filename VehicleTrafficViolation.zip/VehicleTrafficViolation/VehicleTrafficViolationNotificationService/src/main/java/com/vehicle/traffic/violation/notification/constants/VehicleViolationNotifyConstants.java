/**
 * 
 */
package com.vehicle.traffic.violation.notification.constants;

/**
 * This class is used to declare the constants
 * 
 * @author SHANKAR
 *
 */
public class VehicleViolationNotifyConstants {

	public static String URL = "http://localhost:8081/geAlltVoilationForVehicles/";
	public static String MAIL_SUBJECT = "Vehicle Traffic Violation Notification";
	public static String MAIL_CONTENT_TYPE = "text/html";
	public static String UTF_8_CODE = "utf-8";
	public static String MAIL_FROM = "vehicleviolationnotify@outlook.com";
}
