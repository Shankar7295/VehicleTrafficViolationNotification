/**
 * 
 */
package com.vehicle.traffic.violation.notification.service;

import java.util.List;
import java.util.Map;

import com.vehicle.traffic.violation.notification.dto.SignalPoliceDTO;
import com.vehicle.traffic.violation.notification.dto.VehicleViolationDTO;
import com.vehicle.traffic.violation.notification.exception.VehicleViolationNotificationException;

/**
 * This interface is used to vehicle notification service
 * 
 * @author SHANKAR
 *
 */
public interface IVehicleViolationNotifyService {

	/**
	 * THis method is used to send the notification mail to the police
	 * 
	 * @param vehilesViolationMap
	 * @param signalPoliceDTO
	 */
	public void sendAllVehicleViolations(Map<String, List<VehicleViolationDTO>> vehilesViolationMap,
			SignalPoliceDTO signalPoliceDTO) throws VehicleViolationNotificationException;

}
