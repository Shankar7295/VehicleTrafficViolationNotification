/**
 * 
 */
package com.vehicle.traffic.violation.notification.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

/**
 * This class is used to send a vehicle notification data
 * 
 * @author SHANKAR
 *
 */
@Entity
public class VehicleViolationNotification implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "notification_id")
	private int notificationId;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "vehicle_number", nullable = false)
	private Vehicle vehicle = new Vehicle();
	@Column(name = "signal_adrs")
	private String signalAddrs;
	@Column(name = "signal__police_name", nullable = false)
	private String signalPoliceName;
	@Column(name = "signal_police_email_id", nullable = false)
	private String signalPoliceEmailId;
	@Column(name = "notification_date", nullable = false)
	private Date notifiedDate;

	public VehicleViolationNotification() {
		super();
	}

	public VehicleViolationNotification(int notificationId, Vehicle vehicle, String signalAddrs,
			String signalPoliceName, String signalPoliceEmailId, Date notifiedDate) {
		super();
		this.notificationId = notificationId;
		this.vehicle = vehicle;
		this.signalAddrs = signalAddrs;
		this.signalPoliceName = signalPoliceName;
		this.signalPoliceEmailId = signalPoliceEmailId;
		this.notifiedDate = notifiedDate;
	}

	public int getNotificationId() {
		return notificationId;
	}

	public void setNotificationId(int notificationId) {
		this.notificationId = notificationId;
	}

	public Vehicle getVehicle() {
		return vehicle;
	}

	public void setVehicle(Vehicle vehicle) {
		this.vehicle = vehicle;
	}

	public String getSignalAddrs() {
		return signalAddrs;
	}

	public void setSignalAddrs(String signalAddrs) {
		this.signalAddrs = signalAddrs;
	}

	public String getSignalPoliceName() {
		return signalPoliceName;
	}

	public void setSignalPoliceName(String signalPoliceName) {
		this.signalPoliceName = signalPoliceName;
	}

	public String getSignalPoliceEmailId() {
		return signalPoliceEmailId;
	}

	public void setSignalPoliceEmailId(String signalPoliceEmailId) {
		this.signalPoliceEmailId = signalPoliceEmailId;
	}

	public Date getNotifiedDate() {
		return notifiedDate;
	}

	public void setNotifiedDate(Date notifiedDate) {
		this.notifiedDate = notifiedDate;
	}

	@Override
	public String toString() {
		return "VehicleViolationNotification [notificationId=" + notificationId + ", vehicle=" + vehicle
				+ ", signalAddrs=" + signalAddrs + ", signalPoliceName=" + signalPoliceName + ", signalPoliceEmailId="
				+ signalPoliceEmailId + ", notifiedDate=" + notifiedDate + "]";
	}

}
