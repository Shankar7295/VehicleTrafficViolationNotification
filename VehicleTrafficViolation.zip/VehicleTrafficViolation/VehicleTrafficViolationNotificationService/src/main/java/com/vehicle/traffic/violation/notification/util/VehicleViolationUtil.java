/**
 * 
 */
package com.vehicle.traffic.violation.notification.util;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vehicle.traffic.violation.notification.dto.SignalPoliceDTO;
import com.vehicle.traffic.violation.notification.dto.VehicleViolationDTO;
import com.vehicle.traffic.violation.notification.exception.VehicleViolationNotificationException;

/**
 * This is the utility class
 * 
 * @author SHANKAR
 *
 */
public class VehicleViolationUtil {
	private static final Logger LOGGER = LoggerFactory.getLogger(VehicleViolationUtil.class);
	private static boolean flag = true;;

	/**
	 * This method is used to get the mail content
	 * 
	 * @param vehilesViolationMap
	 * @param signalPoliceDTO
	 * @return
	 * @throws VehicleViolationNotificationException
	 */
	public static String getMailContent(Map<String, List<VehicleViolationDTO>> vehilesViolationMap,
			SignalPoliceDTO signalPoliceDTO) throws VehicleViolationNotificationException {
		StringBuffer buffer = new StringBuffer();
		try {
			buffer.append("<html>");
			buffer.append("<head>");
			buffer.append("<style type=\"text/css\">");
			buffer.append("table");
			buffer.append("{border:1px solid black;");
			buffer.append("border-collapse:collapse;}");
			buffer.append("th, td {");
			buffer.append("border: 1px solid black;}");
			buffer.append("</style>");
			buffer.append("</head>");
			buffer.append("<body>");
			buffer.append("<header>");
			buffer.append("<h3>Vehicle Traffic Violation Information</h3>");
			buffer.append("<h5>Police Name : " + signalPoliceDTO.getName() + "</h5>");
			buffer.append("<h5>Signal Address : " + signalPoliceDTO.getSignalAddrs() + "</h5>");
			buffer.append("</header>");
			buffer.append("<table>");
			buffer.append("<tr>");
			buffer.append("<th>Vehicle Number </th>");
			buffer.append("<th>Violation Description </th>");
			buffer.append("<th>Violation Date </th>");
			buffer.append("<th>Fine Amount </th>");
			buffer.append("<th>Total Fine Amount </th>");
			buffer.append("</tr>");

			Set<String> keySet = vehilesViolationMap.keySet();
			ObjectMapper mapper = new ObjectMapper();

			keySet.stream().forEach(key -> {

				List<VehicleViolationDTO> violationList = mapper.convertValue(vehilesViolationMap.get(key),
						new TypeReference<List<VehicleViolationDTO>>() {
						});
				flag = true;
				violationList.stream().forEach(vehicleViolationDTO -> {

					buffer.append("<tr>");
					if (flag) {
						buffer.append("<td rowspan=" + vehilesViolationMap.get(key).size() + ">");
						buffer.append(vehicleViolationDTO.getVehicleNumber());
						buffer.append("</td>");
					}
					buffer.append("<td>");
					buffer.append(vehicleViolationDTO.getViolationDesc());
					buffer.append("</td>");
					buffer.append("<td>");
					buffer.append(vehicleViolationDTO.getViolationDate());
					buffer.append("</td>");
					buffer.append("<td>");
					buffer.append(vehicleViolationDTO.getFineAmount());
					buffer.append("</td>");
					if (flag) {
						buffer.append("<td rowspan=" + vehilesViolationMap.get(key).size() + ">");
						buffer.append(""
								+ violationList.stream().collect(Collectors.summingDouble(dto -> dto.getFineAmount())));
						buffer.append("</td>");
						flag = false;
					}
					buffer.append("</tr>");
				});

			});
			buffer.append("</table>");
			buffer.append("<br/>");
			buffer.append("<br/>");
			buffer.append("<p>Regards,</p>");
			buffer.append("<p>Vehicle Violation Notification Team</p>");
			buffer.append("<br/>");
			buffer.append("<br/>");
			buffer.append("<p><b>**Disclaimer : This is an auto generated mail, please do not reply</b></p>");
			buffer.append("</body>");
			buffer.append("</html>");
		} catch (Exception e) {
			LOGGER.error("Error while composing a mail data, message :{} ", e.getMessage());
			throw new VehicleViolationNotificationException(e);
		}
		return buffer.toString();

	}
}
