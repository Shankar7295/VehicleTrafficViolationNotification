/**
 * 
 */
package com.vehicle.traffic.violation.notification.util;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;

import com.vehicle.traffic.violation.notification.constants.VehicleViolationNotifyConstants;
import com.vehicle.traffic.violation.notification.exception.VehicleViolationNotificationException;

/**
 * This class is used to send a mail
 * 
 * @author SHANKAR
 *
 */
@Component
public class EmailSender {
	private static final Logger LOGGER = LoggerFactory.getLogger(EmailSender.class);
	@Autowired
	private JavaMailSender javaMailSender;

	/**
	 * This method is used to send a mail
	 * 
	 * @param mailContent
	 * @param toMailId
	 * @param subject
	 * @throws VehicleViolationNotificationException
	 */
	public void sendEmail(String mailContent, String toMailId, String subject)
			throws VehicleViolationNotificationException {
		MimeMessage message = javaMailSender.createMimeMessage();
		MimeMessageHelper helper = null;
		try {
			helper = new MimeMessageHelper(message, false, VehicleViolationNotifyConstants.UTF_8_CODE);
			message.setContent(mailContent, VehicleViolationNotifyConstants.MAIL_CONTENT_TYPE);
			helper.setFrom(VehicleViolationNotifyConstants.MAIL_FROM);
			helper.setTo(toMailId);
			helper.setSubject(subject);
			javaMailSender.send(message);
		} catch (MessagingException e) {
			LOGGER.error("Error while sending a mail, message :{} ", e.getMessage());
			throw new VehicleViolationNotificationException(e);
		} catch (Exception exception) {
			LOGGER.error("Error while sending a mail, message :{} ", exception.getMessage());
			throw new VehicleViolationNotificationException(exception);
		}

	}
}
