/**
 * 
 */
package com.vehicle.traffic.violation.notification.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.vehicle.traffic.violation.notification.constants.VehicleViolationNotifyConstants;
import com.vehicle.traffic.violation.notification.dto.VehicleViolationDTO;
import com.vehicle.traffic.violation.notification.dto.VehicleViolationNotificationDTO;
import com.vehicle.traffic.violation.notification.exception.VehicleViolationNotificationException;
import com.vehicle.traffic.violation.notification.service.IVehicleViolationNotifyService;

/**
 * This class is handle the vehicle violation notification requests
 * 
 * @author SHANKAR
 *
 */
@RestController
@RequestMapping(path = "/")
public class VehicleTafficViolationNotifyController {
	private static final Logger LOGGER = LoggerFactory.getLogger(VehicleTafficViolationNotifyController.class);
	@Autowired
	private IVehicleViolationNotifyService vehicleViolationNotifyService;

	@Autowired
	private RestTemplate restTemplate;

	/**
	 * This method is used to send vehicle violation notification mail
	 * 
	 * @param vehicleViolationNotificationDTO
	 */
	@SuppressWarnings("unchecked")
	@PostMapping(path = "sendAllVehicleViolations")
	public void sendAllVehicleViolations(@RequestBody VehicleViolationNotificationDTO vehicleViolationNotificationDTO) {
		LOGGER.info("Send mail request sendAllVehicleViolations() started with details : {} ",
				vehicleViolationNotificationDTO.toString());
		try {
			if (vehicleViolationNotificationDTO.getVehicleList() != null
					&& vehicleViolationNotificationDTO.getVehicleList().size() > 0) {
				String url = VehicleViolationNotifyConstants.URL
						+ String.join(",", vehicleViolationNotificationDTO.getVehicleList());
				Map<String, List<VehicleViolationDTO>> vehileWithListOfViolation = restTemplate.getForObject(url,
						HashMap.class);
				if (vehileWithListOfViolation != null && vehileWithListOfViolation.size() > 0) {
					vehicleViolationNotifyService.sendAllVehicleViolations(vehileWithListOfViolation,
							vehicleViolationNotificationDTO.getSignalPolice());
					LOGGER.info("Send mail request sendAllVehicleViolations() is completed");
				} else {
					LOGGER.info("There are no violations for teh given vehicles");
				}
			}else {
				LOGGER.info("The given vehicle number list is empty");
			}

		} catch (VehicleViolationNotificationException e) {
			LOGGER.error("Error while sending the vehicle violation lists, message :{} ", e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			LOGGER.error("General error while sending the vehicle violation lists, message :{} ", e.getMessage());
			e.printStackTrace();
		}

	}

}
