package com.vehicle.traffic.violation.notification;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

/**
 * This class is used to initialize the vehicle violation notification
 * application
 * 
 * @author SHANKAR
 *
 */
@SpringBootApplication
public class VehicleTrafficViolationNotificationServiceApplication {

	/**
	 * Initialization of the spring boot application
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		SpringApplication.run(VehicleTrafficViolationNotificationServiceApplication.class, args);
	}

	/**
	 * This method is used to create the rest template bean
	 * 
	 * @param builder
	 * @return
	 */
	@Bean
	public RestTemplate restTemplate(RestTemplateBuilder builder) {
		return builder.build();
	}
}
