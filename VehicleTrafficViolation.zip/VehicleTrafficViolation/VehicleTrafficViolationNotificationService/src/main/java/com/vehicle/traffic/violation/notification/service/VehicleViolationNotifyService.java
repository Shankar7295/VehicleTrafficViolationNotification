/**
 * 
 */
package com.vehicle.traffic.violation.notification.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vehicle.traffic.violation.notification.constants.VehicleViolationNotifyConstants;
import com.vehicle.traffic.violation.notification.dto.SignalPoliceDTO;
import com.vehicle.traffic.violation.notification.dto.VehicleViolationDTO;
import com.vehicle.traffic.violation.notification.entity.VehicleViolationNotification;
import com.vehicle.traffic.violation.notification.exception.VehicleViolationNotificationException;
import com.vehicle.traffic.violation.notification.repository.VehicleViolationNotifyRepository;
import com.vehicle.traffic.violation.notification.util.EmailSender;
import com.vehicle.traffic.violation.notification.util.VehicleViolationUtil;

/**
 * This class is used to vehicle notification service
 * 
 * @author SHANKAR
 *
 */
@Service
public class VehicleViolationNotifyService implements IVehicleViolationNotifyService {
	private static final Logger LOGGER = LoggerFactory.getLogger(VehicleViolationNotifyService.class);
	@Autowired
	EmailSender emailSender;

	@Autowired
	VehicleViolationNotifyRepository vehicleViolationNotifyRepository;

	/**
	 * This method is used to send notification mail and add notifiaction history to
	 * the repository
	 */
	@Override
	public void sendAllVehicleViolations(Map<String, List<VehicleViolationDTO>> vehilesViolationMap,
			SignalPoliceDTO signalPoliceDTO) throws VehicleViolationNotificationException {
		LOGGER.info("sending a vehicle traffic violation data over mail started");
		try {
			String mailContent = VehicleViolationUtil.getMailContent(vehilesViolationMap, signalPoliceDTO);
			String subject = VehicleViolationNotifyConstants.MAIL_SUBJECT;
			emailSender.sendEmail(mailContent, signalPoliceDTO.getEmailId(), subject);

			List<VehicleViolationNotification> entities = new ArrayList<VehicleViolationNotification>();
			Set<String> keySet = vehilesViolationMap.keySet();
			keySet.stream().forEach(key -> {
				VehicleViolationNotification notification = new VehicleViolationNotification();
				notification.setNotifiedDate(new Date());
				notification.setSignalAddrs(signalPoliceDTO.getSignalAddrs());
				notification.setSignalPoliceEmailId(signalPoliceDTO.getEmailId());
				notification.setSignalPoliceName(signalPoliceDTO.getName());
				notification.getVehicle().setVehicleNumber(key);
				entities.add(notification);

			});
			vehicleViolationNotifyRepository.saveAll(entities);
		} catch (Exception e) {
			LOGGER.error("Error while sending the vehicle violation mail ", e.getMessage());
			throw e;
		}

	}

}
