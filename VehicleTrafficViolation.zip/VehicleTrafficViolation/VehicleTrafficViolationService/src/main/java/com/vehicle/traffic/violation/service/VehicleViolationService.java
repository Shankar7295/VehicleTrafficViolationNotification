/**
 * 
 */
package com.vehicle.traffic.violation.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vehicle.traffic.violation.dto.VehicleViolationDTO;
import com.vehicle.traffic.violation.entity.VehicleViolation;
import com.vehicle.traffic.violation.exception.VehicleViolationException;
import com.vehicle.traffic.violation.repository.VehicleViolationRepository;

/**
 * This class will be called from controller to get the violation lists of the
 * given vehicles
 * 
 * @author SHANKAR
 *
 */
@Service
public class VehicleViolationService implements IVehicleViolationService {
	private static final Logger LOGGER = LoggerFactory.getLogger(VehicleViolationService.class);

	@Autowired
	VehicleViolationRepository vehicleViolationRepository;

	/**
	 * This is used to get the list of violations of the given vehicle number
	 */
	@Override
	public List<VehicleViolationDTO> getVehicleVoilation(String vehicleNumber) throws VehicleViolationException {
		LOGGER.info("Execution of getVehicleVoilation() started");
		List<VehicleViolation> vehicleViolations = null;
		List<VehicleViolationDTO> vehicleViolationDTOs = null;
		ModelMapper modelMapper = new ModelMapper();
		try {
			vehicleViolations = vehicleViolationRepository.getVehicleViolation(vehicleNumber);
			if (vehicleViolations != null && vehicleViolations.size() > 0) {
				LOGGER.info("vehicleViolations list is not null");
				vehicleViolationDTOs = vehicleViolations.stream()
						.map(vehicleViolation -> modelMapper.map(vehicleViolation, VehicleViolationDTO.class))
						.collect(Collectors.toList());
			}
		} catch (Exception e) {
			LOGGER.error("Error in the process of getting the vehicle violation list, message : {}", e.getMessage());
			throw new VehicleViolationException(e);
		}
		return vehicleViolationDTOs;
	}

	/**
	 * This is used to get the list of violations of the given vehicle numbers
	 */
	@Override
	public Map<String, List<VehicleViolationDTO>> getAllvehicleViolations(List<String> vehicleNumbers)
			throws VehicleViolationException {
		LOGGER.info("Execution of getAllvehicleViolations() started");
		List<VehicleViolation> vehicleViolations = null;
		ModelMapper modelMapper = new ModelMapper();
		Map<String, List<VehicleViolationDTO>> vehicleViolationMap = new HashMap<>();
		try {
			vehicleViolations = vehicleViolationRepository.getAllvehicleViolations(vehicleNumbers);

			if (vehicleViolations != null && vehicleViolations.size() > 0) {
				vehicleViolations.stream().forEach(vehicleViolation -> {

					if (vehicleViolationMap.containsKey(vehicleViolation.getVehicleNumber())) {
						List<VehicleViolationDTO> vehicleViolationDTOs = vehicleViolationMap
								.get(vehicleViolation.getVehicleNumber());
						vehicleViolationDTOs.add(modelMapper.map(vehicleViolation, VehicleViolationDTO.class));
						vehicleViolationMap.put(vehicleViolation.getVehicleNumber(), vehicleViolationDTOs);
					} else {
						List<VehicleViolationDTO> vehicleViolationDTOs = new ArrayList<VehicleViolationDTO>();
						vehicleViolationDTOs.add(modelMapper.map(vehicleViolation, VehicleViolationDTO.class));
						vehicleViolationMap.put(vehicleViolation.getVehicleNumber(), vehicleViolationDTOs);
					}

				});
			}
		} catch (Exception e) {
			LOGGER.error("Error in the process of getting the vehicles violation lists, message : {}", e.getMessage());
			throw new VehicleViolationException(e);
		}
		return vehicleViolationMap;
	}

}
