/**
 * 
 */
package com.vehicle.traffic.violation.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.vehicle.traffic.violation.entity.VehicleViolation;

/**
 * THis class is used as repository to deal with Vehicle_Violation table
 * 
 * @author SHANKAR
 *
 */
@Repository
public interface VehicleViolationRepository extends JpaRepository<VehicleViolation, Integer> {
	/**
	 * This is used to get the list of violations of the given vehicle number
	 * 
	 * @param vehicleNumber
	 * @return
	 * @throws Exception
	 */
	@Query("Select vehicle from VehicleViolation vehicle where vehicle.vehicleNumber=:vehicleNumber")
	public List<VehicleViolation> getVehicleViolation(@Param("vehicleNumber") String vehicleNumber) throws Exception;

	/**
	 * This is used to get the list of violations of the given vehicle numbers
	 * 
	 * @param vehicleNumbers
	 * @return
	 * @throws Exception
	 */
	@Query("Select vehicle from VehicleViolation vehicle where vehicle.vehicleNumber in (:vehicleNumbers) and vehicle.violationCleared=false")
	public List<VehicleViolation> getAllvehicleViolations(@Param("vehicleNumbers") List<String> vehicleNumbers)
			throws Exception;

}
