/**
 * 
 */
package com.vehicle.traffic.violation.exception;

/**
 * This class is use create used defined exceptions
 * 
 * @author SHANKAR
 *
 */
public class VehicleViolationException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public VehicleViolationException() {
		super();
	}

	public VehicleViolationException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public VehicleViolationException(String message, Throwable cause) {
		super(message, cause);
	}

	public VehicleViolationException(String message) {
		super(message);
	}

	public VehicleViolationException(Throwable cause) {
		super(cause);
	}

}
