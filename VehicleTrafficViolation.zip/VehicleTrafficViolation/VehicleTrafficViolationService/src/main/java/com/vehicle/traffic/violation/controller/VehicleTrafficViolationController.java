package com.vehicle.traffic.violation.controller;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.vehicle.traffic.violation.dto.VehicleViolationDTO;
import com.vehicle.traffic.violation.exception.VehicleViolationException;
import com.vehicle.traffic.violation.service.IVehicleViolationService;

/**
 * This class is used to accept the requests and process it.
 * 
 * @author SHANKAR
 *
 */
@RestController
@RequestMapping(path = "/")
public class VehicleTrafficViolationController {
	private static final Logger LOGGER = LoggerFactory.getLogger(VehicleTrafficViolationController.class);
	@Autowired
	private IVehicleViolationService vehicleViolationService;

	/**
	 * This method is used to get the violation list of the vehicle
	 * 
	 * @param vehicleNumber
	 * @return
	 */
	@GetMapping(path = "getVoilationForVehicles/{vehicleNumber}")
	public List<VehicleViolationDTO> getVoilationForVehicles(@PathVariable("vehicleNumber") String vehicleNumber) {
		LOGGER.info("Get request getVoilationForVehicles() with vehicle number : {} is started", vehicleNumber);
		List<VehicleViolationDTO> vehicleVoilations = null;
		try {
			if (vehicleNumber != null) {
				vehicleVoilations = vehicleViolationService.getVehicleVoilation(vehicleNumber);
			} else {
				LOGGER.info("Given vehicle number is null");
			}

			LOGGER.info("Get request getVoilationForVehicles() completed with result : {}",
					vehicleVoilations != null ? vehicleVoilations.toString() : null);
		} catch (VehicleViolationException e) {
			LOGGER.error("Error while processing the GET request to get the vehicle violation lists, message :{} ",
					e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			LOGGER.error(
					"General error while processing the GET request to get the vehicle violation lists, message :{} ",
					e.getMessage());
			e.printStackTrace();
		}
		return vehicleVoilations;

	}

	/**
	 * This method is used to get the violation lists of the given vehicle using
	 * vehicle numbers
	 * 
	 * @param vehicleNumbers
	 * @return
	 */
	@GetMapping(path = "geAlltVoilationForVehicles/{vehicleNumbers}")
	public Map<String, List<VehicleViolationDTO>> geAlltVoilationForVehicles(
			@PathVariable("vehicleNumbers") String vehicleNumbers) {
		LOGGER.info("Get request geAlltVoilationForVehicles() with vehicle numbers : {} is started", vehicleNumbers);
		Map<String, List<VehicleViolationDTO>> vehicleVoilations = null;
		try {
			if (vehicleNumbers != null) {
				vehicleVoilations = vehicleViolationService
						.getAllvehicleViolations(Arrays.asList(vehicleNumbers.split(",")));
			} else {
				LOGGER.info("Given vehicle number list is empty");
			}

			LOGGER.info("Get request geAlltVoilationForVehicles() completed with result : {}",
					vehicleVoilations.toString());
		} catch (VehicleViolationException e) {
			LOGGER.error("Error while processing the GET request to get the vehicle violation lists, message:{}",
					e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			LOGGER.error("Genral error while processing the GET request to get the vehicle violation lists, message:{}",
					e.getMessage());
			e.printStackTrace();
		}
		return vehicleVoilations;

	}

}
