package com.vehicle.traffic.violation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

/**
 * This class is used to initialize the Vehicle TrafficViolation Service
 * Application
 * 
 * @author SHANKAR
 *
 */
@EnableDiscoveryClient
@SpringBootApplication
public class VehicleTrafficViolationServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(VehicleTrafficViolationServiceApplication.class, args);
	}

}
