/**
 * 
 */
package com.vehicle.traffic.violation.util;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.vehicle.traffic.violation.entity.VehicleViolation;
import com.vehicle.traffic.violation.repository.VehicleViolationRepository;

/**
 * This class is used load the pre-data for the vehicle violation database
 * 
 * @author SHANKAR
 *
 */
@Component
public class VehicleViolationDataLoader implements CommandLineRunner {

	@Autowired
	VehicleViolationRepository vehicleViolationRepository;

	@Override
	public void run(String... args) throws Exception {
		vehicleViolationRepository.deleteAll();
		for (int i = 0; i < 10; i++) {
			VehicleViolation vehicleViolation = new VehicleViolation();
			vehicleViolation.setVehicleNumber("IN" + i);
			vehicleViolation.setViolationDesc("Signal Jump");
			vehicleViolation.setViolationDate(new Date());
			vehicleViolation.setFineAmount(1000.00);
			vehicleViolationRepository.save(vehicleViolation);
		}

		for (int i = 2; i < 5; i++) {
			VehicleViolation vehicleViolation = new VehicleViolation();
			vehicleViolation.setVehicleNumber("IN" + i);
			vehicleViolation.setViolationDesc("Over Speed");
			vehicleViolation.setViolationDate(new Date());
			vehicleViolation.setFineAmount(2000.00);
			vehicleViolationRepository.save(vehicleViolation);
		}

	}

}
