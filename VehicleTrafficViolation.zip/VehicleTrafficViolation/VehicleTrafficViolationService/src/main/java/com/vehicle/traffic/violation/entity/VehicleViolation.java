package com.vehicle.traffic.violation.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * This class is used yo deal with the database for Vehicle violation
 * 
 * @author SHANKAR
 *
 */

@Entity
@Table(name = "vehicle_violation")
public class VehicleViolation implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	@Column(name = "vehicle_number", nullable = false)
	private String vehicleNumber;
	@Column(name = "violation_desc", nullable = false)
	private String violationDesc;
	@Column(name = "violation_date", nullable = false)
	private Date violationDate;
	@Column(name = "fine_amount", nullable = false)
	private Double fineAmount;
	@Column(name = "violation_cleared")
	private boolean violationCleared = false;
	@Column(name = "violation_cleared_date")
	private Date violationClearedDate;

	public VehicleViolation() {
		super();
	}

	public VehicleViolation(int id, String vehicleNumber, String violationDesc, Date violationDate, Double fineAmount,
			boolean violationCleared, Date violationClearedDate) {
		super();
		this.id = id;
		this.vehicleNumber = vehicleNumber;
		this.violationDesc = violationDesc;
		this.violationDate = violationDate;
		this.fineAmount = fineAmount;
		this.violationCleared = violationCleared;
		this.violationClearedDate = violationClearedDate;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getVehicleNumber() {
		return vehicleNumber;
	}

	public void setVehicleNumber(String vehicleNumber) {
		this.vehicleNumber = vehicleNumber;
	}

	public String getViolationDesc() {
		return violationDesc;
	}

	public void setViolationDesc(String violationDesc) {
		this.violationDesc = violationDesc;
	}

	public Date getViolationDate() {
		return violationDate;
	}

	public void setViolationDate(Date violationDate) {
		this.violationDate = violationDate;
	}

	public Double getFineAmount() {
		return fineAmount;
	}

	public void setFineAmount(Double fineAmount) {
		this.fineAmount = fineAmount;
	}

	public boolean isViolationCleared() {
		return violationCleared;
	}

	public void setViolationCleared(boolean violationCleared) {
		this.violationCleared = violationCleared;
	}

	public Date getViolationClearedDate() {
		return violationClearedDate;
	}

	public void setViolationClearedDate(Date violationClearedDate) {
		this.violationClearedDate = violationClearedDate;
	}

	@Override
	public String toString() {
		return "VehicleViolation [id=" + id + ", vehicleNumber=" + vehicleNumber + ", violationDesc=" + violationDesc
				+ ", violationDate=" + violationDate + ", fineAmount=" + fineAmount + ", violationCleared="
				+ violationCleared + ", violationClearedDate=" + violationClearedDate + "]";
	}

}
