/**
 * 
 */
package com.vehicle.traffic.violation.service;

import java.util.List;
import java.util.Map;

import com.vehicle.traffic.violation.dto.VehicleViolationDTO;
import com.vehicle.traffic.violation.exception.VehicleViolationException;

/**
 * This interface is used to add the service layer methods for the vehicle
 * violation flow
 * 
 * @author SHANKAR
 *
 */
public interface IVehicleViolationService {

	/**
	 * This is used to get the list of violations of the given vehicle number
	 * 
	 * @param vehicleNumber
	 * @return
	 * @throws VehicleViolationException
	 */
	public List<VehicleViolationDTO> getVehicleVoilation(String vehicleNumber) throws VehicleViolationException;

	/**
	 * This is used to get the list of violations of the given vehicle numbers
	 * 
	 * @param vehicleNumbers
	 * @return
	 * @throws VehicleViolationException
	 */
	public Map<String, List<VehicleViolationDTO>> getAllvehicleViolations(List<String> vehicleNumbers)
			throws VehicleViolationException;

}
