/**
 * 
 */
package com.vehicle.traffic.violation.constants;

/**
 * This class can be used to add any constants used in the application
 * 
 * @author SHANKAR
 *
 */
public class VehicleViolationConstants {

}
