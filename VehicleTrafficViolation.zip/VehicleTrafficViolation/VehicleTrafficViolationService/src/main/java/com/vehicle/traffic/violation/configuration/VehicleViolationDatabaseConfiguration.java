/**
 * 
 */
package com.vehicle.traffic.violation.configuration;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.vehicle.traffic.violation.entity.VehicleViolation;

/**
 * This class is used to initialize the data source and transaction manager
 * 
 * @author SHANKAR
 *
 */
@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(basePackages = "com.vehicle.traffic.violation.repository", entityManagerFactoryRef = "vehicleVoilationEntyMangrFactory", transactionManagerRef = "vehicleVoilationTransactionManager")
public class VehicleViolationDatabaseConfiguration {

	private static final Logger LOGGER = LoggerFactory.getLogger(VehicleViolationDatabaseConfiguration.class);

	/**
	 * Data source bean creation with name as vehicleVoilationDatasource
	 * 
	 * @return
	 */
	@Bean(name = "vehicleVoilationDatasource")
	@ConfigurationProperties(prefix = "spring.datasource")
	public DataSource vehicleVoilationDatasource() {
		LOGGER.info("Initializing the datasource vehicleVoilationDatasource");
		return DataSourceBuilder.create().build();
	}

	/**
	 * Transaction manager bean creation
	 * 
	 * @param vehicleVoilationTransactionManager
	 * @return
	 */
	@Bean(name = "vehicleVoilationTransactionManager")
	public PlatformTransactionManager vehicleVoilationTransactionManager(
			LocalContainerEntityManagerFactoryBean vehicleVoilationTransactionManager) {
		LOGGER.info("Initializing the transaction manager vehicleVoilationTransactionManager");
		return new JpaTransactionManager(vehicleVoilationTransactionManager.getObject());
	}

	/**
	 * Entity manager factory bean creation
	 * 
	 * @param vehicleVoilationDatasource
	 * @param builder
	 * @return
	 */
	@Bean(name = "vehicleVoilationEntyMangrFactory")
	public LocalContainerEntityManagerFactoryBean vehicleVoilationEntyMangrFactory(
			@Qualifier("vehicleVoilationDatasource") DataSource vehicleVoilationDatasource,
			EntityManagerFactoryBuilder builder) {
		LOGGER.info("Initializing the entity manager vehicleVoilationEntyMangrFactory");
		return builder.dataSource(vehicleVoilationDatasource).packages(VehicleViolation.class).build();
	}
}
