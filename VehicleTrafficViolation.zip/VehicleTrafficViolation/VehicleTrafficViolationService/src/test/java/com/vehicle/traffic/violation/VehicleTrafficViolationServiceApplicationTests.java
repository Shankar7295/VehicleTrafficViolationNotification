package com.vehicle.traffic.violation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VehicleTrafficViolationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
