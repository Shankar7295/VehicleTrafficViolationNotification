package com.vehicle.traffic.discovery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VehicleTrafficViolationDiscoveryServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
