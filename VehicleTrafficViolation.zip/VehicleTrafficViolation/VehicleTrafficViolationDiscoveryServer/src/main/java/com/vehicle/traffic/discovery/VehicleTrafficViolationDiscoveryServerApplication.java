package com.vehicle.traffic.discovery;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

/**
 * This class is used to create the discovery server
 * 
 * @author SHANKAR
 *
 */
@EnableEurekaServer
@SpringBootApplication
public class VehicleTrafficViolationDiscoveryServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(VehicleTrafficViolationDiscoveryServerApplication.class, args);
	}

}
